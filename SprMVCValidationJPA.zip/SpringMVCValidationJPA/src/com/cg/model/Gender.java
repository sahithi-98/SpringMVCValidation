package com.cg.model;

public class Gender {
	
	private String type;
	
	public Gender() {
		// TODO Auto-generated constructor stub
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
	
}
