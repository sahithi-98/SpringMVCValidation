package com.cg.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cg.dao.TraineeRepository;
import com.cg.model.Gender;
import com.cg.model.Trainee;


@Controller
public class TraineeController {
	@Autowired
	Trainee trainee;
	@Autowired
	Validator validator;
	@Autowired
	TraineeRepository traineeRepository;

	@RequestMapping(value = "/loginlink", method = RequestMethod.GET)
	public String loginlink() {
		return "login";

	}

	@RequestMapping("/loginvalidation")
	public ModelAndView login(HttpServletRequest request) {
		ModelAndView modelView = new ModelAndView();
		String username = request.getParameter("uname");
		String password = request.getParameter("pwd");
		Trainee trainee=traineeRepository.validate(username, password);
		if (trainee!=null) {
			HttpSession session = request.getSession();
			session.setAttribute("user", trainee);
			modelView.setViewName("home");
		} else {
			modelView.addObject("status", "Invalid username/password");
			modelView.setViewName("login");

		}
		return modelView;
	}
	@RequestMapping("/registerlink")
	public String registerlink(ModelMap map)
	{
		map.addAttribute(trainee);
		return "register";
	}
	
	@ModelAttribute("genderlist")
	public List<Gender> populate(){
		ArrayList<Gender> list=new ArrayList<>();
		Gender g1=new Gender();
		g1.setType("male");
		Gender g2=new Gender();
		g2.setType("Female");
		Gender g3= new Gender();
		g3.setType("others");
		list.add(g1);
		list.add(g2);
		list.add(g3);
		return list;
	}
	@RequestMapping(value="/registerdata",method=RequestMethod.POST)
	public ModelAndView register(Trainee t,BindingResult br,ModelMap map)
	{
		ModelAndView mv= new ModelAndView();
		validator.validate(t, br);
		if(br.hasErrors()) {
			mv.setViewName("register");
			map.addAttribute("status","Not registered try again");
		}
		boolean status=traineeRepository.register(t);
		if(status)
		{
			mv.setViewName("login");
			map.addAttribute("status","Registered Successfully...");
		}
		else
		{
			mv.setViewName("register");
			map.addAttribute("status","Not registered try again");
		}
		return mv;
		
		
	}
}
