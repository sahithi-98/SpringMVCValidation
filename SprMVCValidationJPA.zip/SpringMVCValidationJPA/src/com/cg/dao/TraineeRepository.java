package com.cg.dao;

import com.cg.model.Trainee;

public interface TraineeRepository {

		Trainee validate(String username,String password);
		boolean register(Trainee trainee);
		boolean update(Trainee trainee);
		Trainee view(int tid);
		String forgotpassword(String username);
}
