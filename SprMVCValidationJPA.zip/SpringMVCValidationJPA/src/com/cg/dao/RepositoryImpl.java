package com.cg.dao;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.model.Trainee;

@Repository("traineeRepository")
public class RepositoryImpl implements TraineeRepository {
	@PersistenceContext
	private EntityManager entitymanager;

	public EntityManager getEntitymanager() {
		return entitymanager;
	}

	public void setEntitymanager(EntityManager entitymanager) {
		this.entitymanager = entitymanager;
	}

	@Override
	public Trainee validate(String username, String password) {
		Query q=entitymanager.createQuery("from Trainee t where t.username=?1 and t.password=?2");
		q.setParameter(1, username);
		q.setParameter(2, password);
		q.setMaxResults(1);
		List<Trainee> traineelist=q.getResultList();
		Trainee newtrainee=null;
		if(traineelist.size()>0)
		{
		 newtrainee=traineelist.get(0);
		}
		if(newtrainee!=null)
		{
			return newtrainee;
		}
		return null;
	}

	@Transactional
	@Override
	public boolean register(Trainee trainee) {
		entitymanager.persist(trainee);
		Trainee trainee1 = entitymanager.find(Trainee.class, trainee.getTid());
		if (trainee1 != null)
			return true;
		else
			return false;
	}

	@Transactional
	@Override
	public boolean update(Trainee trainee) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Trainee view(int tid) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String forgotpassword(String username) {
		// TODO Auto-generated method stub
		return null;
	}

}
